export default fuction useTarjeta() {
}